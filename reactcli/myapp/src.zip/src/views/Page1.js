import React, { Component } from 'react'

export default class Page1 extends Component {
  render() {
    return (
      <div>
        <h1>页面一</h1>
      </div>
    )
  }
}

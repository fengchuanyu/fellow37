<template>
  <div class="about">
    <h1 class="active">This is an about page</h1>
    <h1>vuex-count:{{$store.state.count}}</h1>
    <!-- <button @click="addHandle">add</button> -->
    <button @click="$store.commit('add')">add</button>
  </div>
</template>
<script>
export default {
  methods:{
    addHandle(){
      console.log(this.$store.state.count);
      
      this.$store.commit("add");
    }
  }
}
</script>

